#include <stdio.h>
#include <string.h>
#include <math.h>
#pragma warning(disable:4996 6031)

                // --- D�CLARATION DES CONSTANTES (�num�ration pour les limites) ---
// Ces constantes d�finissent la taille maximale des tableaux et les param�tres cl�s de la formation.

enum {
    MAX_ETUDIANTS = 100,           // Nombre maximum d'�tudiants que le syst�me peut g�rer.
    NB_UE = 6,                    // Nombre d'Unit�s d'Enseignement (UE) par semestre/ann�e.
    NB_SEMESTRES = 6,            // Nombre total de semestres (S1 � S6) dans le cursus.
    NB_ANNEES = 3,              // Nombre total d'ann�es (A1 � A3) dans le cursus.
    MAX_NOM = 31,              // Longueur maximale pour les pr�noms et noms des �tudiants.
    MAX_STATUT = 16,          // Longueur maximale pour la cha�ne de statut (e.g., "en cours", "ajourne").
    MIN_RCUE_VALIDE = 4,     // R�gle de passage : Nombre minimum de RCUE (R�gimes de Contr�le des Unit�s d'Enseignement) � valider pour les ann�es A1 et A2 (4 sur 6).
    SEMESTRE_IMPAIR = 1,    // Marqueur pour un semestre impair (S1, S3, S5).
    SEMESTRE_PAIR = 0      // Marqueur pour un semestre pair (S2, S4, S6).
};

      // Constantes pour les notes et les seuils de validation
const float NOTE_MIN = 0.0f;          // Note minimale possible.
const float NOTE_MAX = 20.0f;        // Note maximale possible.
const float NOTE_INCONNUE = -1.0f;  // Valeur utilis�e pour marquer une note qui n'a pas encore �t� saisie.
const float SEUIL_PASSAGE = 10.0f; // Seuil minimum pour valider une UE ou un RCUE par capitalisation/compensation (ADM).
const float SEUIL_AJB = 8.0f;     // Seuil minimum pour un RCUE (strictement inf�rieur � 8/20 entra�ne l'ajournement "AJB").
const float SEUIL_ADS = 8.0f;    // Seuil minimum pour qu'une UE soit "ADS" (Admise Sans compensation) si le RCUE n'est pas valid�.


            // --- STRUCTURES DE DONN�ES ---
// D�finition des types composites pour stocker les informations du cursus.

typedef struct {
    float note;       // La note obtenue dans l'Unit� d'Enseignement (UE).
    char code[4];    // Code de validation de l'UE ("ADM", "AJ", "ADC", "ADS", etc.).
} NoteUE;

typedef struct {
    float note;       // La note moyenne calcul�e pour le Regroupement d'Unit�s d'Enseignement (RCUE).
    char code[4];    // Code de validation du RCUE ("ADM", "AJ", "AJB").
} RCUE;

typedef struct {
    int ID;                                              // Identifiant unique de l'�tudiant.
    char PRENOM[MAX_NOM];                               // Pr�nom de l'�tudiant.
    char NOM[MAX_NOM];                                 // Nom de l'�tudiant.
    NoteUE NOTES_PAR_SEMESTRE[NB_SEMESTRES][NB_UE];   // Tableau 2D des notes (6 semestres x 6 UE).
    RCUE BILAN_RCUE[NB_ANNEES][NB_UE];               // Tableau 2D des r�sultats des RCUE (3 ann�es x 6 RCUE).
    int semestre_actuel;                            // Indice du semestre en cours (0 � 5).
    char STATUT[MAX_STATUT];                       // Statut actuel de l'�tudiant ("en cours", "demission", "ajourne", "diplome").
} Etudiant;


         // --- FONCTION UTILITAIRE ---

float tronquerNote(float note) {         // Tronque la note � une d�cimale pour l'affichage, conform�ment � la r�gle: floorf(note * 10.f) / 10.f.
    return floorf(note * 10.0f) / 10.0f;
}


// --- COMMANDES (FONCTIONS DE GESTION) ---

void INSCRIRE(Etudiant etudiant[], int* nb_etu, char PRENOM[], char NOM[]) {
    // Ajoute un nouvel �tudiant au tableau `etudiant` et initialise ses donn�es.

    // V�rifie si l'�tudiant existe d�j� pour �viter les doublons.
    for (int i = 0; i < *nb_etu; ++i) {
        if (strcmp(etudiant[i].PRENOM, PRENOM) == 0 && strcmp(etudiant[i].NOM, NOM) == 0) {
            printf("Nom incorrect\n");
            return;
        }
    }

    // V�rifie si la capacit� maximale d'�tudiants est atteinte.
    if (*nb_etu >= MAX_ETUDIANTS) {
        printf("Nombre maximum d'etudiants atteint\n");
        return;
    }

    // Pointeur sur la nouvelle structure Etudiant � initialiser.
    Etudiant* nouv = &etudiant[*nb_etu];
    nouv->ID = (*nb_etu) + 1;
    strcpy(nouv->PRENOM, PRENOM);
    strcpy(nouv->NOM, NOM);
    nouv->semestre_actuel = 0;          // Commence au premier semestre (indice 0 pour S1).
    strcpy(nouv->STATUT, "en cours");  // Statut initial.

    // Initialisation de toutes les notes d'UE � la valeur inconnue (-1.0f) et code � "*".
    for (int s = 0; s < NB_SEMESTRES; ++s) {
        for (int u = 0; u < NB_UE; ++u) {
            nouv->NOTES_PAR_SEMESTRE[s][u].note = NOTE_INCONNUE;
            strcpy(nouv->NOTES_PAR_SEMESTRE[s][u].code, "*");
        }
    }
    // Initialisation des notes de RCUE � la valeur inconnue et code � "*".
    for (int a = 0; a < NB_ANNEES; ++a) {
        for (int u = 0; u < NB_UE; ++u) {
            nouv->BILAN_RCUE[a][u].note = NOTE_INCONNUE;
            strcpy(nouv->BILAN_RCUE[a][u].code, "*");
        }
    }

    (*nb_etu)++;     // Incr�mente le compteur total d'�tudiants.
    printf("Inscription enregistree (%d)\n", nouv->ID);
}

void NOTE(Etudiant etudiant[], int nb_etu, int id, int ue, float note) {     // Enregistre une note pour une UE sp�cifique dans le semestre actuel de l'�tudiant.// V�rification de l'Identifiant (ID)
    if (id <= 0 || id > nb_etu) {
        printf("Identifiant incorrect\n");
        return;
    }
    Etudiant* etu = &etudiant[id - 1];     // R�cup�re la structure Etudiant.

    // V�rification du statut : seule la saisie de notes est autoris�e pour les �tudiants "en cours" ou "ajourne".
    if (strcmp(etu->STATUT, "en cours") != 0 && strcmp(etu->STATUT, "ajourne") != 0) {
        printf("Etudiant hors formation\n");
        return;
    }

    // V�rification de l'indice de l'UE (doit �tre entre 1 et NB_UE)
    if (ue < 1 || ue > NB_UE) {
        printf("UE incorrecte\n");
        return;
    }
    // V�rification de la validit� de la note (doit �tre entre NOTE_MIN et NOTE_MAX)
    if (note < NOTE_MIN || note > NOTE_MAX) {
        printf("Note incorrecte\n");
        return;
    }

    // Enregistrement de la note.
    int s_actuel = etu->semestre_actuel;  // Indice du semestre actuel.
    int ue_idx = ue - 1;                 // Indice de l'UE (0 � NB_UE-1).

    etu->NOTES_PAR_SEMESTRE[s_actuel][ue_idx].note = note;
    // Le code est r�initialis� � "*" en attendant la prochaine d�lib�ration du JURY (ou affich� par CURSUS).
    strcpy(etu->NOTES_PAR_SEMESTRE[s_actuel][ue_idx].code, "*");

    printf("Note enregistree\n");
}

void CURSUS(Etudiant etudiant[], int nb_etu, int id) {
    // Affiche le cursus complet d'un �tudiant (notes par semestre et bilans annuels).

    // V�rification de l'ID
    if (id <= 0 || id > nb_etu) {
        printf("Identifiant incorrect\n");
        return;
    }
    Etudiant* etu = &etudiant[id - 1];

    printf("%d %s %s\n", etu->ID, etu->PRENOM, etu->NOM);

    // Boucle sur tous les semestres atteints (de S1 jusqu'au semestre actuel inclus)
    for (int s = 0; s <= etu->semestre_actuel; ++s) {
        printf("S%d", s + 1); // Affichage du num�ro de semestre (1 � 6).

        // Affichage des 6 UE du semestre
        for (int u = 0; u < NB_UE; ++u) {
            NoteUE* note_ue = &etu->NOTES_PAR_SEMESTRE[s][u];

            if (note_ue->note == NOTE_INCONNUE) {
                // Si la note est inconnue, affichage de l'indicateur par d�faut.
                printf(" - * (*)");
            }
            else {
                char code_affiche[4];

                // D�termination du code � afficher :
                if (strcmp(note_ue->code, "*") == 0) {
                    // Si le code n'a pas �t� fix� par le jury, on affiche le statut temporaire.
                    if (note_ue->note >= SEUIL_PASSAGE) strcpy(code_affiche, "ADM"); // Admission provisoire
                    else strcpy(code_affiche, "AJ");                                // Ajournement provisoire
                }
                else {
                    // Sinon, on affiche le code final fix� par le jury (ADM, ADC, ADS, AJ, etc.).
                    strcpy(code_affiche, note_ue->code);
                }
                // Affichage de la note tronqu�e et du code associ�.
                printf(" - %.1f (%s)", tronquerNote(note_ue->note), code_affiche);
            }
        }

        // Affichage du statut � la fin du semestre actuel
        if (s == etu->semestre_actuel) {
            printf(" - %s\n", etu->STATUT);
        }
        else {
            printf("\n"); // Fin de ligne si ce n'est pas le dernier semestre atteint.
        }

        // Affichage du Bilan Annuel (B1, B2, B3) apr�s les semestres pairs (S2, S4, S6).

        if (s % 2 != 0) {           // Si c'est un semestre pair (s=1 pour S2, s=3 pour S4, s=5 pour S6)
            int annee_idx = s / 2; // Indice de l'ann�e (0 pour A1, 1 pour A2, 2 pour A3).

            // Afficher le Bilan uniquement si le jury l'a calcul� (code non '*').
            if (strcmp(etu->BILAN_RCUE[annee_idx][0].code, "*") != 0) {
                printf("B%d", annee_idx + 1);

                for (int u = 0; u < NB_UE; ++u) {
                    RCUE* rcue = &etu->BILAN_RCUE[annee_idx][u];
                    // Affichage de la note RCUE tronqu�e et du code.
                    printf(" - %.1f (%s)", tronquerNote(rcue->note), rcue->code);
                }

                // Affichage du statut sur la ligne Bilan si l'�tudiant est ajourn� ou dipl�m�.
                if (strcmp(etu->STATUT, "ajourne") == 0 || strcmp(etu->STATUT, "diplome") == 0) {
                    printf(" - %s\n", etu->STATUT);
                }
                else {
                    printf("\n");
                }
            }
        }
    }
}


void ETUDIANTS(Etudiant etudiant[], int nb_etu) {
    // Affiche la liste des �tudiants avec leur ID, nom, semestre actuel et statut.
    for (int i = 0; i < nb_etu; ++i) {
        printf("%d - %s %s - S%d - %s\n",
            etudiant[i].ID,
            etudiant[i].PRENOM,
            etudiant[i].NOM,
            etudiant[i].semestre_actuel + 1, // Affichage du S actuel (+1 car l'indice est base 0)
            etudiant[i].STATUT);
    }
}

void DEMISSION(Etudiant etudiant[], int nb_etu, int id) {
    // Met � jour le statut d'un �tudiant � "demission".

    if (id <= 0 || id > nb_etu) {
        printf("Identifiant incorrect\n");
        return;
    }
    Etudiant* etu = &etudiant[id - 1];

    // Ne permet de d�missionner que si l'�tudiant est "en cours" 
    if (strcmp(etu->STATUT, "en cours") != 0) {
        printf("Etudiant hors formation\n");
        return;
    }

    strcpy(etu->STATUT, "demission");
    printf("Demission enregistree\n");
}

void DEFAILLANCE(Etudiant etudiant[], int nb_etu, int id) {
    // Met � jour le statut d'un �tudiant � "defaillance".

    if (id <= 0 || id > nb_etu) {
        printf("Identifiant incorrect\n");
        return;
    }
    Etudiant* etu = &etudiant[id - 1];

    // Ne permet la d�faillance que si l'�tudiant est "en cours".
    if (strcmp(etu->STATUT, "en cours") != 0) {
        printf("Etudiant hors formation\n");
        return;
    }

    strcpy(etu->STATUT, "defaillance");
    printf("Defaillance enregistree\n");
}


void JURY(Etudiant etudiant[], int nb_etu, int semestre) {
    // Effectue la d�lib�ration du jury pour le semestre donn�.

    if (semestre < 1 || semestre > NB_SEMESTRES) {
        printf("Semestre incorrect\n");
        return;
    }
    int semestre_idx = semestre - 1; // Indice du semestre (0 � 5).

    // Phase 1 : V�rification des notes manquantes (pour le semestre actuel et le semestre impair pr�c�dent si Jury Pair)
    int etudiants_a_traiter = 0;
    for (int i = 0; i < nb_etu; ++i) {
        Etudiant* etu = &etudiant[i];

        // Traiter uniquement les �tudiants "en cours" ou "ajourne" qui sont actuellement dans le semestre soumis au jury.
        if ((strcmp(etu->STATUT, "en cours") == 0 || strcmp(etu->STATUT, "ajourne") == 0) &&
            etu->semestre_actuel == semestre_idx) {

            int check_semestre_precedent = (semestre % 2 == SEMESTRE_PAIR);

            for (int u = 0; u < NB_UE; ++u) {
                // V�rification du semestre actuel
                if (etu->NOTES_PAR_SEMESTRE[semestre_idx][u].note == NOTE_INCONNUE) {
                    printf("Des notes sont manquantes\n");
                    return;
                }
                // V�rification du semestre impair pr�c�dent (uniquement pour les jurys pairs : S2, S4, S6)
                if (check_semestre_precedent && semestre_idx > 0 &&
                    etu->NOTES_PAR_SEMESTRE[semestre_idx - 1][u].note == NOTE_INCONNUE) {
                    printf("Des notes sont manquantes\n");
                    return;
                }
            }
            etudiants_a_traiter++; // Compte l'�tudiant � traiter par le jury.
        }
    }

    if (etudiants_a_traiter == 0) {
        printf("Semestre termine pour 0 etudiant(s)\n");
        return;
    }

    // Phase 2 : Traitement et d�cision (Passage au semestre suivant ou Ajournement/Dipl�me)
    int etudiants_passes = 0;

    for (int i = 0; i < nb_etu; ++i) {
        Etudiant* etu = &etudiant[i];

        if (etu->semestre_actuel == semestre_idx &&
            (strcmp(etu->STATUT, "en cours") == 0 || strcmp(etu->STATUT, "ajourne") == 0)) {

            // --- JURY IMPAIR (S1, S3, S5) ---
            if (semestre % 2 != 0) {

                 // R�gle : Passage de droit au semestre suivant (S2, S4, S6).
                // Les UE sont valid�es individuellement sans compensation.
                for (int u = 0; u < NB_UE; ++u) {
                    NoteUE* note_ue = &etu->NOTES_PAR_SEMESTRE[semestre_idx][u];
                    if (note_ue->note >= SEUIL_PASSAGE) {
                        strcpy(note_ue->code, "ADM");     // Admis si >= 10.0
                    }
                    else {
                        strcpy(note_ue->code, "AJ");     // Ajourn� si < 10.0
                    }
                }

                // Passage au semestre suivant (si ce n'est pas le dernier semestre)
                if (semestre_idx < NB_SEMESTRES - 1) {
                    etu->semestre_actuel++;
                    strcpy(etu->STATUT, "en cours");
                }
                etudiants_passes++;
            }

            // --- JURY PAIR (S2, S4, S6) ---
            else {
                int annee_idx = semestre_idx / 2;      // Indice de l'ann�e (0 pour A1, 1 pour A2, 2 pour A3).
                int nb_rcue_adm = 0;                  // Compteur de RCUE valid�s (ADM).
                int has_rcue_ajb = 0;                // Indicateur d'ajournement bloquant (AJB).
                int tout_ue_valide_annee = 1;       // Indicateur de validation de toutes les UE.

                // 2. Traitement RCUE et Compensation UE
                for (int u = 0; u < NB_UE; ++u) {
                    NoteUE* ue_impair = &etu->NOTES_PAR_SEMESTRE[semestre_idx - 1][u];  // UE du semestre N-1 (impair)
                    NoteUE* ue_pair = &etu->NOTES_PAR_SEMESTRE[semestre_idx][u];       // UE du semestre N (pair)
                    RCUE* rcue = &etu->BILAN_RCUE[annee_idx][u];                      // RCUE de l'ann�e

                    // Calcul de la moyenne RCUE (moyenne des deux UE)
                    rcue->note = (ue_impair->note + ue_pair->note) / 2.0f;
                    int rcue_valide = (rcue->note >= SEUIL_PASSAGE);

                    // D�termination du code RCUE
                    if (rcue->note >= SEUIL_PASSAGE) {
                        strcpy(rcue->code, "ADM");
                        nb_rcue_adm++;
                    }
                    else if (rcue->note < SEUIL_AJB) {
                        strcpy(rcue->code, "AJB"); // Ajournement bloquant si moyenne < 8.0
                        has_rcue_ajb = 1;
                    }
                    else {
                        strcpy(rcue->code, "AJ");  // Ajournement simple si 8.0 <= moyenne < 10.0
                    }

                    // Application de la compensation aux UE (si RCUE ADM)
                    if (rcue_valide) {
                        // Si le RCUE est valid�, les UE sont ADM si >= 10.0, ou ADC (Admis par Compensation) si < 10.0.
                        if (ue_impair->note < SEUIL_PASSAGE) strcpy(ue_impair->code, "ADC");
                        else strcpy(ue_impair->code, "ADM");

                        if (ue_pair->note < SEUIL_PASSAGE) strcpy(ue_pair->code, "ADC");
                        else strcpy(ue_pair->code, "ADM");

                    }
                    else {
                         // Pas de compensation (RCUE AJ ou AJB) : validation individuelle des UE.
                        // UE Impair : ADM (>=10), ADS (>=8), AJ (<8)
                        if (ue_impair->note >= SEUIL_PASSAGE) strcpy(ue_impair->code, "ADM");
                        else if (ue_impair->note >= SEUIL_ADS) strcpy(ue_impair->code, "ADS"); // Admis Sans Compensation
                        else strcpy(ue_impair->code, "AJ");

                        // UE Pair : ADM (>=10), ADS (>=8), AJ (<8)
                        if (ue_pair->note >= SEUIL_PASSAGE) strcpy(ue_pair->code, "ADM");
                        else if (ue_pair->note >= SEUIL_ADS) strcpy(ue_pair->code, "ADS");
                        else strcpy(ue_pair->code, "AJ");
                    }

                    // V�rifie si l'UE est valid�e par l'ann�e pour la condition de passage (ADM ou ADC)
                    if (strcmp(ue_pair->code, "ADM") != 0 && strcmp(ue_pair->code, "ADC") != 0) {
                        tout_ue_valide_annee = 0;
                    }
                }

                // 3. D�cision Semestre (S2, S4, S6)
                int passe = 0;

                // S2/S4 : R�ussite si (>= MIN_RCUE_VALIDE RCUE ADM) ET (pas d'AJB)
                if (semestre_idx == 1 || semestre_idx == 3) {
                    passe = (nb_rcue_adm >= MIN_RCUE_VALIDE) && !has_rcue_ajb;
                }
                // S6 : Dipl�me si (Toutes les UE valid�es: ADM ou ADC)
                else if (semestre_idx == 5) {
                    passe = tout_ue_valide_annee;
                }

                if (passe) {
                    etudiants_passes++;
                    // Passage au semestre suivant (S3, S5) ou Dipl�me (si S6)
                    if (semestre_idx < NB_SEMESTRES - 1) {
                        etu->semestre_actuel++;
                        strcpy(etu->STATUT, "en cours");
                    }
                    else {
                        strcpy(etu->STATUT, "diplome");
                    }
                }
                else {
                    // Si l'�tudiant n'a pas r�ussi l'ann�e.
                    strcpy(etu->STATUT, "ajourne");
                }

                // Si l'�tudiant a pass� au semestre suivant, r�initialisation de ses notes dans ce nouveau semestre.
                if (etu->semestre_actuel == semestre_idx + 1) {
                    for (int u = 0; u < NB_UE; ++u) {
                        etu->NOTES_PAR_SEMESTRE[etu->semestre_actuel][u].note = NOTE_INCONNUE;
                        strcpy(etu->NOTES_PAR_SEMESTRE[etu->semestre_actuel][u].code, "*");
                    }
                }
            }
        }
    }

    printf("Semestre termine pour %d etudiant(s)\n", etudiants_passes);
}

void BILAN(Etudiant etudiant[], int nb_etu, int annee) {
    // Affiche le bilan statistique pour une ann�e donn�e (A1, A2 ou A3).

    if (annee < 1 || annee > NB_ANNEES) {
        printf("Annee incorrecte\n");
        return;
    }

    int demissions = 0;
    int defaillances = 0;
    int en_cours = 0;
    int ajournes = 0;
    int passes = 0;

    int annee_idx = annee - 1;            // Indice de l'ann�e (0 � 2).
    int s_impair_idx = annee_idx * 2;    // Indice du premier semestre de l'ann�e (S1, S3, S5).
    int s_pair_idx = annee_idx * 2 + 1; // Indice du deuxi�me semestre de l'ann�e (S2, S4, S6).

    for (int i = 0; i < nb_etu; ++i) {
        Etudiant* etu = &etudiant[i];

        // Ignore les �tudiants qui n'ont pas encore commenc� cette ann�e.
        if (etu->semestre_actuel < s_impair_idx) {
            continue;
        }

        // 1. Statuts d�finitifs (D�mission / D�faillance)
        if (strcmp(etu->STATUT, "demission") == 0) {
            // Compte si la d�mission a eu lieu pendant cette ann�e (S_impair ou S_pair)
            if (etu->semestre_actuel == s_impair_idx || etu->semestre_actuel == s_pair_idx) {
                demissions++;
            }
        }
        else if (strcmp(etu->STATUT, "defaillance") == 0) {
            // Compte si la d�faillance a eu lieu pendant cette ann�e
            if (etu->semestre_actuel == s_impair_idx || etu->semestre_actuel == s_pair_idx) {
                defaillances++;
            }
        }

        // 2. Statuts du Jury de fin d'ann�e (S2/S4/S6)
        else if (etu->semestre_actuel == s_pair_idx) {
            // Est ajourn� (apr�s le jury S2/S4/S6).
            if (strcmp(etu->STATUT, "ajourne") == 0) {
                ajournes++;
            }
            // Est dipl�m� (uniquement apr�s le jury S6)
            else if (strcmp(etu->STATUT, "diplome") == 0 && annee == NB_ANNEES) {
                passes++;
            }
            // Est pass� � l'ann�e suivante ("en cours" � la fin du S2/S4)
            else if (strcmp(etu->STATUT, "en cours") == 0) {
                passes++;
            }
        }

        // 3. Est pass� � l'ann�e suivante (semestre_actuel > s_pair_idx, e.g., au S3 pour l'ann�e A1)
        else if (etu->semestre_actuel > s_pair_idx) {
            passes++;
        }

        // 4. Est en cours dans cette ann�e (S_impair ou S_pair en cours)
        else if (strcmp(etu->STATUT, "en cours") == 0) {
            if (etu->semestre_actuel == s_impair_idx || etu->semestre_actuel == s_pair_idx) {
                en_cours++;
            }
        }
    }

    // Affichage des r�sultats
    printf("%d demission(s)\n", demissions);
    printf("%d defaillance(s)\n", defaillances);
    printf("%d en cours\n", en_cours);
    printf("%d ajourne(s)\n", ajournes);
    printf("%d passe(s)\n", passes);
}


int main() {
    // D�claration du tableau pour stocker tous les �tudiants.
    Etudiant etudiant[MAX_ETUDIANTS];
    int nb_etu = 0;          // Compteur d'�tudiants actuellement inscrits.
    char cde[MAX_NOM] = ""; // Cha�ne de caract�res pour stocker la commande lue en entr�e.

     // La logique d'initialisation des �tudiants non utilis�s est minimis�e, 
    // l'initialisation compl�te �tant faite dans la fonction INSCRIRE.

    // Boucle principale de lecture des commandes (jusqu'� la commande "EXIT").
    do {
        // Lecture de la commande depuis l'entr�e standard (stdin).
        if (scanf("%s", cde) != 1) break;

        // Traitement des commandes disponibles
        if (strcmp(cde, "INSCRIRE") == 0) {
            char prenom[MAX_NOM], nom[MAX_NOM];
            if (scanf("%s %s", prenom, nom) != 2) break; // Lecture du pr�nom et du nom.
            INSCRIRE(etudiant, &nb_etu, prenom, nom);
        }
        else if (strcmp(cde, "NOTE") == 0) {
            int id; float note; int ue;
            if (scanf("%d %d %f", &id, &ue, &note) != 3) break; // Lecture ID, UE, Note.
            NOTE(etudiant, nb_etu, id, ue, note);
        }
        else if (strcmp(cde, "CURSUS") == 0) {
            int id;
            if (scanf("%d", &id) != 1) break; // Lecture ID.
            CURSUS(etudiant, nb_etu, id);
        }
        else if (strcmp(cde, "ETUDIANTS") == 0) {
            ETUDIANTS(etudiant, nb_etu); // Pas d'arguments suppl�mentaires.
        }
        else if (strcmp(cde, "DEMISSION") == 0) {
            int id;
            if (scanf("%d", &id) != 1) break; // Lecture ID.
            DEMISSION(etudiant, nb_etu, id);
        }
        else if (strcmp(cde, "DEFAILLANCE") == 0) {
            int id;
            if (scanf("%d", &id) != 1) break; // Lecture ID.
            DEFAILLANCE(etudiant, nb_etu, id);
        }
        else if (strcmp(cde, "JURY") == 0) {
            int semestre;
            if (scanf("%d", &semestre) != 1) break; // Lecture Semestre.
            JURY(etudiant, nb_etu, semestre);
        }
        else if (strcmp(cde, "BILAN") == 0) {
            int annee;
            if (scanf("%d", &annee) != 1) break; // Lecture Ann�e.
            BILAN(etudiant, nb_etu, annee);
        }
    } while (strcmp(cde, "EXIT") != 0); // La boucle continue tant que la commande n'est pas "EXIT".

    return 0; // Fin normale du programme.
}